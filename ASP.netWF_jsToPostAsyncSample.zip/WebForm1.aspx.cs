﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // ポストバック時は何もしない
            if (Page.IsPostBack)
            {
                return;

            }


            this.txtMsg.Text = "初期化完了";

        }

        protected async void btnExecute_Click(object sender, EventArgs e)
        {

            List<string> paramters = new List<string>();
            paramters.Add("item1");
            paramters.Add("item2");

            Task<bool> task = new Task<bool>(() => LongTimeProcessAsync.businessLogicTestAsync(paramters));
            task.Start();

            bool result = await task;

            if (result)
            {
                this.Label1.Text = "実行完了です。実行できます。";
                this.txtMsg.Text = "正常終了";
            }
            else
            {
                this.Label1.Text = "実行中です。しばらくおまちください。";
            }
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            //　処理中：閉じるのときは何もしない
            this.txtMsg.Text = "";


            this.Label1.Text = "処理中ダイアログを閉じましたが、処理は継続中です。";
        }

    }
}