﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace WebApplication2
{
    public class LongTimeProcessAsync
    {

        public static bool businessLogicTestAsync(List<string> parameter)
        {

            bool result = true;
            StreamWriter writer = null;
            try
            {
                writer = new StreamWriter("sample.txt", true, System.Text.Encoding.UTF8);
                for (int i = 0; i < 20; i++)
                {
                    writer.WriteLine(parameter.ToString());
                    System.Threading.Thread.Sleep(1000);
                }
                
            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.InnerException);
                result = false;
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
            return result;
        }
    }
}